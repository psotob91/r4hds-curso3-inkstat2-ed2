# Este es mi primer script en R
# cinco más ocho; tres por 23; veinte elevado al cubo; setenta y tres entre cinco

5 + 8

3 * 23

20 ^ 3

73 / 5